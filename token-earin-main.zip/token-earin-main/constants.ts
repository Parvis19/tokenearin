import { AppConfig } from './types';

export const DEFAULT_CONFIG: AppConfig = {
  minWithdrawal: 5000,
  coinValueCoins: 1000,
  coinValueBdt: 12,
  referralBonus: 100,
  adWatchReward: 10,
  miningConfig: { 
    miningDuration: 43200, 
    basePointsPerHour: 0.05 
  },
  sliderBanners: [
    { img: "https://picsum.photos/600/300?random=1", link: "#" },
    { img: "https://picsum.photos/600/300?random=2", link: "#" }
  ],
  websitesToVisit: [
    { name: "Global News", link: "https://google.com", reward: 15, timer: 10 },
    { name: "Crypto Tracker", link: "https://coinmarketcap.com", reward: 20, timer: 15 }
  ],
  socialTasks: [
    { name: "Join Telegram", link: "https://t.me/tokentfr_bot", reward: 50 }
  ],
  paymentMethods: [
    { name: "Bkash", placeholder: "Enter Bkash Number" },
    { name: "Nagad", placeholder: "Enter Nagad Number" },
    { name: "Free Fire Diamond", placeholder: "Enter Player ID" },
    { name: "Binance Pay ID", placeholder: "Enter Pay ID / UID" }
  ],
  telegramBot: { botName: "tokentfr_bot" }
};