import { initializeApp } from "firebase/app";
import { getAuth } from "firebase/auth";
import { initializeFirestore, persistentLocalCache, persistentMultipleTabManager } from "firebase/firestore";
import { getStorage } from "firebase/storage";

const firebaseConfig = {
  apiKey: "AIzaSyD0K6yWblqzsazyitPN01AN-zvzJhUSi6E",
  authDomain: "cryptopk0bot.firebaseapp.com",
  projectId: "cryptopk0bot",
  storageBucket: "cryptopk0bot.firebasestorage.app",
  messagingSenderId: "477664356645",
  appId: "1:477664356645:web:6cf7b9d05013f0d2a952cc"
};

const app = initializeApp(firebaseConfig);
export const auth = getAuth(app);

/**
 * Initializing Firestore with experimentalForceLongPolling enabled.
 * This is a common fix for "Could not reach Cloud Firestore backend" (code: unavailable) errors,
 * which often occur due to ISP restrictions or firewalls blocking WebSockets.
 */
export const db = initializeFirestore(app, {
  localCache: persistentLocalCache({
    tabManager: persistentMultipleTabManager()
  }),
  experimentalForceLongPolling: true
});

export const storage = getStorage(app);