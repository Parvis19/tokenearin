
import { 
  doc, setDoc, updateDoc, collection, addDoc, 
  serverTimestamp, query, where, getDocs, writeBatch, getDoc 
} from "firebase/firestore";
import { updateProfile, type User as FirebaseUser } from "firebase/auth";
import { db } from "./firebase";

export const UserService = {
  async createProfile(user: FirebaseUser, name: string, referrerCode: string | null) {
    const referralCode = name.toLowerCase().replace(/\s/g, '');
    
    // Uniqueness check
    const q = query(collection(db, "users"), where("referralCode", "==", referralCode));
    const snap = await getDocs(q);
    if (!snap.empty) throw new Error("Username already taken");

    const newUser = {
      uid: user.uid,
      name,
      email: user.email || 'anonymous',
      balance: 50,
      referralCode,
      referredBy: referrerCode || null,
      referralCount: 0,
      referralEarnings: 0,
      createdAt: serverTimestamp(),
      isBlocked: false,
      dailyAdCount: 0,
      visitedWebsitesToday: [],
      completedSocialTasks: [],
      miningData: {
        lastMiningStart: Math.floor(Date.now() / 1000),
        miningPoints: 0,
        isMining: true
      }
    };

    await setDoc(doc(db, "users", user.uid), newUser);
    await updateProfile(user, { displayName: name });

    // Handle referral bonus if code provided during onboarding
    if (referrerCode) {
      try {
        await this.redeemReferral(user.uid, referrerCode, true);
      } catch (e) {
        console.warn("Initial referral failed:", e);
      }
    }
  },

  async redeemReferral(uid: string, referrerCode: string, isInitial: boolean = false) {
    const userRef = doc(db, "users", uid);
    const userSnap = await getDoc(userRef);
    if (!userSnap.exists()) throw new Error("User not found");
    
    const userData = userSnap.data();
    if (userData.referredBy && !isInitial) throw new Error("Referral already claimed");
    if (userData.referralCode === referrerCode) throw new Error("Cannot use own code");

    const refQ = query(collection(db, "users"), where("referralCode", "==", referrerCode));
    const refSnap = await getDocs(refQ);
    
    if (refSnap.empty) throw new Error("Invalid referral code");
    
    const referrerDoc = refSnap.docs[0];
    const bonus = 100;
    const batch = writeBatch(db);
    
    // Reward Referrer
    batch.update(doc(db, "users", referrerDoc.id), {
      balance: (referrerDoc.data().balance || 0) + bonus,
      referralCount: (referrerDoc.data().referralCount || 0) + 1,
      referralEarnings: (referrerDoc.data().referralEarnings || 0) + bonus
    });
    
    // Reward New User and mark as referred
    batch.update(userRef, { 
      balance: (userData.balance || 0) + 100,
      referredBy: referrerCode 
    });
    
    await batch.commit();
  },

  async updateBalance(uid: string, currentBalance: number, amount: number, type: string, desc: string) {
    const newBalance = currentBalance + amount;
    await updateDoc(doc(db, "users", uid), { balance: newBalance });
    await addDoc(collection(db, "users", uid, "transactions"), {
      amount, type, description: desc, timestamp: serverTimestamp()
    });
    return newBalance;
  }
};
