
export interface UserData {
  uid: string;
  name: string;
  email: string;
  photoURL?: string;
  balance: number;
  referralCode: string;
  referredBy?: string;
  referralCount: number;
  referralEarnings: number;
  isBlocked: boolean;
  dailyAdCount: number;
  visitedWebsitesToday: string[];
  completedSocialTasks: string[];
  language?: 'en' | 'bn' | 'hi' | 'ur';
  miningData: {
    lastMiningStart: number;
    miningPoints: number;
    isMining: boolean;
  };
}

export interface AppConfig {
  minWithdrawal: number;
  coinValueCoins: number;
  coinValueBdt: number;
  referralBonus: number;
  adWatchReward: number;
  miningConfig: {
    miningDuration: number;
    basePointsPerHour: number;
  };
  sliderBanners: Array<{ img: string; link: string }>;
  websitesToVisit: Array<{ name: string; link: string; reward: number; timer: number }>;
  socialTasks: Array<{ name: string; link: string; reward: number }>;
  paymentMethods: Array<{ name: string; placeholder: string }>;
  telegramBot: { botName: string };
}
