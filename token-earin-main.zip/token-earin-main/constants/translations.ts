export const translations = {
  en: {
    nav: { refer: 'Refer', wallet: 'Wallet', home: 'Home', history: 'History', profile: 'Profile', oracle: 'Oracle' },
    home: { surfing: 'Surfing', mining: 'Mining', ads: 'Ads', social: 'Social', download: 'Download APK', activeBonus: 'Active Bonus', target: 'Daily Target' },
    mining: { hash: 'Mining Hash', progress: 'Mining Progress', cycle: 'Full Cycle', hours: 'Hours', claim: 'CLAIM MINED COINS', processing: 'MINING IN PROGRESS...' },
    wallet: { balance: 'Balance', estPayout: 'Estimated Payout', newRequest: 'New Payout Request', requestBtn: 'REQUEST WITHDRAWAL', status: 'Payout Status', manualAudit: 'Manual Audit: 24-72 hours' },
    refer: { title: 'Refer & Earn', network: 'Total Network', earnings: 'Total Earnings', link: 'Invitation Link', inviteBtn: 'INVITE FRIENDS' },
    ads: { title: 'Watch & Earn', desc: 'Earn instant rewards by supporting our sponsors.', today: 'Today', earnings: 'Earnings', next: 'Next Reward', watchBtn: 'WATCH NOW', processing: 'Processing in' },
    tasks: { surfingTitle: 'Surfing Wall', socialTitle: 'Social Missions', downloadTitle: 'APK Forge', desc: 'Complete quests to fill your bags.', wait: 'wait', success: 'Success!', fail: 'Verification failed.', empty: 'Quest list empty' },
    profile: { settings: 'Account Settings', security: 'Manage security & alias', region: 'Region & Language', signout: 'Sign Out', endSession: 'End current session', verified: 'Verified Network Member', upload: 'Upload from Device', addUrl: 'Add Image URL', tip: 'Tip: If upload fails, use imgbb.com link.', downloadApk: 'Download APK' },
    history: { title: 'Earnings Ledger', subtitle: 'Transaction Audit Log', fetching: 'Fetching Data...', noRecords: 'No records found', verified: 'NETWORK VERIFIED' },
    onboarding: { title: 'CHOOSE ALIAS', desc: 'Pick a unique identity. This will also be your referral code.', placeholder: 'Enter username', btn: 'START EARNING' },
    auth: { slogan: 'Mine. Complete. Earn. Repeat.', google: 'Continue with Google', secure: 'Secure Access', login: 'LOG IN', signup: 'CREATE ACCOUNT', reset: 'SEND RESET LINK', forgot: 'Forgot Password?', new: 'New to the network?', haveAcc: 'Already have an account?', back: 'Back to Login' },
    common: { back: 'Back to Lobby', coins: 'COINS', memberTier: 'Standard Member', restricted: 'Account Restricted', syncVerified: 'SYNC VERIFIED' },
    oracle: { 
      title: 'Network Oracle', 
      subtitle: 'AI Guided Earning', 
      placeholder: 'Ask the Oracle anything...', 
      systemRole: 'You are the Token Earin Oracle, a helpful AI guide. The minimum withdrawal is 5000 coins.',
      suggestions: ['How to earn faster?', 'How to withdraw?', 'Tell me a joke']
    }
  },
  bn: {
    nav: { refer: 'রেফার', wallet: 'ওয়ালেট', home: 'হোম', history: 'ইতিহাস', profile: 'প্রোফাইল', oracle: 'ওরাকল' },
    home: { surfing: 'সার্ফিং', mining: 'মাইনিং', ads: 'অ্যাড', social: 'সোশ্যাল', download: 'এপিকে ডাউনলোড', activeBonus: 'অ্যাক্টিভ বোনাস', target: 'আজকের লক্ষ্য' },
    mining: { hash: 'মাইনিং হ্যাশ', progress: 'মাইনিং অগ্রগতি', cycle: 'পূর্ণ চক্র', hours: 'ঘণ্টা', claim: 'কয়েন সংগ্রহ করুন', processing: 'মাইনিং চলছে...' },
    wallet: { balance: 'ব্যালেন্স', estPayout: 'সম্ভাব্য পেমেন্ট', newRequest: 'নতুন পেমেন্ট রিকোয়েস্ট', requestBtn: 'উত্তোলন রিকোয়েস্ট পাঠান', status: 'পেমেন্ট স্ট্যাটাস', manualAudit: 'অডিট সময়: ২৪-৭২ ঘণ্টা' },
    refer: { title: 'রেফার এবং ইনকাম', network: 'মোট নেটওয়ার্ক', earnings: 'মোট ইনকাম', link: 'রেফারেল লিঙ্ক', inviteBtn: 'বন্ধুদের ইনভাইট করুন' },
    ads: { title: 'দেখুন এবং আয় করুন', desc: 'আমাদের স্পনসরদের সমর্থন করে তাৎক্ষণিক পুরস্কার জিতুন।', today: 'আজকের', earnings: 'মোট আয়', next: 'পরবর্তী পুরস্কার', watchBtn: 'এখনই দেখুন', processing: 'প্রসেসিং হচ্ছে' },
    tasks: { surfingTitle: 'সার্ফিং ওয়াল', socialTitle: 'সোশ্যাল মিশন', downloadTitle: 'এপিকে ডাউনলোড', desc: 'কয়েন জিততে টাস্কগুলো সম্পন্ন করুন।', wait: 'সেকেন্ড অপেক্ষা', success: 'সফল হয়েছে!', fail: 'ভেরিফিকেশন ব্যর্থ হয়েছে।', empty: 'টাস্ক লিস্ট খালি' },
    profile: { settings: 'অ্যাকাউন্ট সেটিংস', security: 'নিরাপত্তা ও নাম পরিবর্তন', region: 'দেশ ও ভাষা', signout: 'লগ আউট', endSession: 'বর্তমান সেশন শেষ করুন', verified: 'ভেরিফাইড মেম্বার', upload: 'ডিভাইস থেকে আপলোড', addUrl: 'লিঙ্ক যোগ করুন', tip: 'টিপ: আপলোড না হলে imgbb.com লিঙ্ক ব্যবহার করুন।', downloadApk: 'এপিকে ডাউনলোড' },
    history: { title: 'আয়ের খতিয়ান', subtitle: 'ট্রানজ্যাকশন অডিট লগ', fetching: 'ডাটা লোড হচ্ছে...', noRecords: 'কোনো রেকর্ড পাওয়া যায়নি', verified: 'নেটওয়ার্ক ভেরিফাইড' },
    onboarding: { title: 'নাম নির্বাচন করুন', desc: 'একটি ইউনিক নাম বেছে নিন। এটিই আপনার রেফার কোড হবে।', placeholder: 'ইউজার নেম দিন', btn: 'ইনকাম শুরু করুন' },
    auth: { slogan: 'মাইন। কমপ্লিট। আর্ন। রিপিট।', google: 'গুগল দিয়ে লগইন', secure: 'নিরাপদ প্রবেশ', login: 'লগ ইন', signup: 'অ্যাকাউন্ট তৈরি করুন', reset: 'রিসেট লিঙ্ক পাঠান', forgot: 'পাসওয়ার্ড ভুলে গেছেন?', new: 'নতুন সদস্য?', haveAcc: 'আগেই অ্যাকাউন্ট আছে?', back: 'লগইনে ফিরে যান' },
    common: { back: 'লবিতে ফিরে যান', coins: 'কয়েন', memberTier: 'সাধারণ সদস্য', restricted: 'অ্যাকাউন্ট সীমাবদ্ধ', syncVerified: 'সিঙ্ক ভেরিফাইড' },
    oracle: { title: 'নেটওয়ার্ক ওরাকল', subtitle: 'এআই ইনকাম গাইড', placeholder: 'ওরাকলকে কিছু জিজ্ঞাসা করুন...', systemRole: 'আপনি টোকেন আর্ন ওরাকল।', suggestions: ['কিভাবে ইনকাম বাড়াবো?', 'উত্তোলন কিভাবে করব?', 'একটি জোকস বলো'] }
  },
  hi: {
    nav: { refer: 'রেফার', wallet: 'वॉलेट', home: 'होम', history: 'इतिहास', profile: 'प्रोफ़ाइल', oracle: 'ओरेकल' },
    home: { surfing: 'সर्फिंग', mining: 'माइनिंग', ads: 'विज्ञापन', social: 'सोशल', download: 'APK डाउनलोड', activeBonus: 'सक्रिय बोनस', target: 'दैनिक लक्ष्य' },
    mining: { hash: 'माइनिंग हैश', progress: 'माइनिंग प्रगति', cycle: 'पूर्ण चक्र', hours: 'घंटे', claim: 'सिक्के क्लेम करें', processing: 'माइनिंग जारी है...' },
    wallet: { balance: 'बैलेंस', estPayout: 'अनुमानित भुगतान', newRequest: 'नया भुगतान अनुरोध', requestBtn: 'निकासी अनुरोध', status: 'भुगतान की स्थिति', manualAudit: 'ऑडिट समय: 24-72 घंटे' },
    refer: { title: 'रेफर करें और कमाएं', network: 'कुल नेटवर्क', earnings: 'कुल कमाई', link: 'निमंत्रण लिंक', inviteBtn: 'दोस्तों को आमंत्रित करें' },
    ads: { title: 'देखें और कमाएं', desc: 'प्रायोजकों का समर्थन करके तत्काल पुरस्कार प्राप्त करें।', today: 'आज', earnings: 'कमाई', next: 'अगला इनाम', watchBtn: 'अभी देखें', processing: 'प्रक्रिया जारी है' },
    tasks: { surfingTitle: 'सर्फिंग वॉल', socialTitle: 'सोशल मिशन', downloadTitle: 'APK डाउनलोड', desc: 'पुरस्कार पाने के लिए मिशन पूरा करें।', wait: 'सेकंड प्रतीक्षा करें', success: 'सफल!', fail: 'सत्यापन विफल।', empty: 'कोई मिशन नहीं' },
    profile: { settings: 'खाता सेटिंग्स', security: 'सुरक्षा और उपनाम प्रबंधित करें', region: 'क्षेत्र और भाषा', signout: 'साइन आउट', endSession: 'सत्र समाप्त करें', verified: 'सत्यापित नेटवर्क सदस्य', upload: 'उपलोड करें', addUrl: 'यूआरएल जोड़ें', tip: 'टिप: यदि अपलोड विफल हो जाए, तो imgbb.com लिंक का उपयोग करें।', downloadApk: 'APK डाउनलोड' },
    history: { title: 'आय का लेखा-जोखा', subtitle: 'लेनदेन ऑडिट लॉग', fetching: 'डेटा प्राप्त हो रहा है...', noRecords: 'कोई रिकॉर्ड नहीं मिला', verified: 'नेटवर्क द्वारा सत्यापित' },
    onboarding: { title: 'नाम चुनें', desc: 'एक विशिष्ट पहचान चुनें।', placeholder: 'उपयोगकर्ता नाम दर्ज करें', btn: 'कमाई शुरू करें' },
    auth: { slogan: 'माइन। पूरा करें। कमाएं। दोहराएं।', google: 'गूगल के साथ जारी रखें', secure: 'सुरक्षित पहुंच', login: 'लॉग इन', signup: 'अकाउंट बनाएं', reset: 'रीसेट लिंक भेजें', forgot: 'पासवर्ड भूल गए?', new: 'नेटवर्क में नए हैं?', haveAcc: 'पहले से ही एक खाता है?', back: 'लॉगिन पर वापस' },
    common: { back: 'लॉबी में वापस', coins: 'सिक्के', memberTier: 'सामान्य सदस्य', restricted: 'खाता प्रतिबंधित', syncVerified: 'सिंक सत्यापित' },
    oracle: { title: 'नेटवर्क ओरेकल', subtitle: 'AI गाइडेड अर्निंग', placeholder: 'ओरेकल से कुछ भी पूछें...', systemRole: 'आप टोकन अर्न ओरेकल हैं।', suggestions: ['तेजी से कैसे कमाएं?', 'निकासी कैसे करें?', 'एक जोक सुनाओ'] }
  }
};